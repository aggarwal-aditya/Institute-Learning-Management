create procedure clear_database()
    language plpgsql
as
$$
BEGIN
    DELETE FROM course_enrollments;
    DELETE FROM course_offerings;
    DELETE FROM course_catalog;
    DELETE FROM semester;
    DELETE FROM students;
    DELETE FROM instructors;
    DELETE FROM departments;
    DELETE FROM users;
END;
$$;

alter procedure clear_database() owner to postgres;

