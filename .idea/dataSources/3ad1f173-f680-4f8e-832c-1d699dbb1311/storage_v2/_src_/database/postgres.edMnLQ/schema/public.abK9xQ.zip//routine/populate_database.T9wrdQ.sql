create procedure populate_database()
    language plpgsql
as
$$
BEGIN
    -- Insert users
    INSERT INTO users VALUES ('2020csb1066@iitrpr.ac.in','aditya','student');
    INSERT INTO users VALUES ('mudgal@yopmail.com','aditya','instructor');
    INSERT INTO users VALUES ('admin@yopmail.com','aditya','admin');

    -- Insert departments and instructor
    INSERT INTO departments (id,name) VALUES (1,'Computer Science');
    INSERT into instructors (instructor_id,email_id,name,phone_number,department_id,date_of_joining) VALUES (1,'mudgal@yopmail.com','Apurva Mudgal','8989872980',1,now());

    -- Insert students
    INSERT into students VALUES ('2020CSB1066','2020csb1066@iitrpr.ac.in','Aditya Aggarwal','8989872980',1,'2024');

    -- Insert semester
    INSERT into semester VALUES (2022,2,'2022-12-20','2023-05-25','2023-01-20','2023-05-25','2022-12-20','2023-03-15','2022-12-25','2022-03-16');
    INSERT into semester VALUES (2022,1,'2022-07-20','2022-11-30','2022-11-20','2022-11-30','2022-07-20','2022-08-15','2022-07-25','2022-08-16');

    -- Insert course_catalog
    INSERT INTO course_catalog VALUES ('CS201','Data Structures',ARRAY[3,1,2,2,4]);
    INSERT INTO course_catalog VALUES ('CS202','Algorithms',ARRAY[3,1,2.5,6.5,3]);
    INSERT INTO course_catalog VALUES ('CS203','Digital Logic Design',ARRAY[3,1,2.5,6.5,3]);

    -- Insert course_offerings
    INSERT into course_offerings VALUES ('CS201','2022-2',1);
    INSERT into course_offerings VALUES ('CS202','2022-1',1);
    INSERT into course_offerings VALUES ('CS203','2022-2',1);

    -- Insert course_enrollments
    INSERT INTO course_enrollments (enrollment_id,course_code, semester,student_id,grade) values (1,'CS201','2022-2','2020CSB1066','A');
    INSERT INTO course_enrollments (enrollment_id,course_code, semester,student_id,grade) values (2,'CS202','2022-1','2020CSB1066','A-');
END;
$$;

alter procedure populate_database() owner to postgres;

