create function update_course_enrollment_count() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        UPDATE course_offerings
        SET enrollment_count = enrollment_count - 1
        WHERE course_code = OLD.course_code
          AND semester = OLD.semester;
    ELSIF (TG_OP = 'INSERT') THEN
        UPDATE course_offerings
        SET enrollment_count = enrollment_count + 1
        WHERE course_code = NEW.course_code
          AND semester = NEW.semester;
    END IF;
    RETURN NEW;
END;
$$;

alter function update_course_enrollment_count() owner to postgres;

