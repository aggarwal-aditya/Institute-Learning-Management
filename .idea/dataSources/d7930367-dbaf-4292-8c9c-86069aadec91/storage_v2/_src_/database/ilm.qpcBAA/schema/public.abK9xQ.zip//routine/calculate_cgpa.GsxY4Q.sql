create function calculate_cgpa(p_student_id character varying) returns numeric
    language plpgsql
as
$$
DECLARE
    total_credits     NUMERIC;
    earned_credits    NUMERIC;
    grade_value       NUMERIC;
    course_enrollment RECORD;
BEGIN
    total_credits := 0;
    earned_credits := 0;

    -- calculate total credits and earned credits
    FOR course_enrollment IN (SELECT course_enrollments.course_code, semester, grade, credit_str
                              FROM course_enrollments
                                       JOIN course_catalog
                                            ON course_enrollments.course_code = course_catalog.course_code
                              WHERE student_id = p_student_id AND course_enrollments.grade<>'NA')
        LOOP
            -- check if the grade is not null
            IF course_enrollment.grade IS NOT NULL THEN
                total_credits := total_credits + course_enrollment.credit_str[5];
                -- get grade value from grade_mapping
                SELECT value INTO grade_value FROM grade_mapping WHERE grade = course_enrollment.grade;
                earned_credits := earned_credits + (course_enrollment.credit_str[5] * grade_value);
            END IF;
        END LOOP;

    -- calculate CGPA
    IF total_credits = 0 THEN
        RETURN 0;
    ELSE
        RETURN earned_credits * (1.0) / (total_credits * 1.0);
    END IF;
END;
$$;

alter function calculate_cgpa(varchar) owner to postgres;

