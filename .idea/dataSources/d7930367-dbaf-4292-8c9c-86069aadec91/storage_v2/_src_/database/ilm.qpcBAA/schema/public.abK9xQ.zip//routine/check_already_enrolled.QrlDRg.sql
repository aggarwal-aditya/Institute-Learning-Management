create function check_already_enrolled() returns trigger
    language plpgsql
as
$$

BEGIN
    IF EXISTS(SELECT 1
              FROM course_enrollments
              WHERE course_code = new.course_code
                AND semester = new.semester
                AND student_id = new.student_id) THEN
        RAISE EXCEPTION 'The student is already enrolled in the course.';
    END IF;

    IF EXISTS(SELECT 1
              FROM course_enrollments
              WHERE course_code = new.course_code
                AND grade != 'F'
                AND student_id = new.student_id) THEN
        RAISE EXCEPTION 'The student has already completed the course earlier.';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_already_enrolled() owner to postgres;

