create function check_student_requirements(enrollment_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
    dept_id             INTEGER;
    grad_year           INTEGER;
    core_count          INTEGER;
    hs_elect_count      INTEGER;
    pc_elect_count      INTEGER;
    sm_elect_count      INTEGER;
    oe_elect_count      INTEGER;
    internship_count    INTEGER;
    btech_project_count INTEGER;
    total_credits       NUMERIC;
    current_credits     NUMERIC;
    course_type         VARCHAR(32);
    current_course      RECORD;
BEGIN
    -- Get the department ID and year for the student
    SELECT department_id, batch INTO dept_id, grad_year FROM students WHERE student_id = $1;

    -- Get the required number of courses for the student's department and year
    SELECT core_count,
           hs_elect_count,
           pc_elect_count,
           sm_elect_count,
           oe_elect_count,
           internship_count,
           btech_project_count
    INTO core_count, hs_elect_count, pc_elect_count, sm_elect_count, oe_elect_count, internship_count, btech_project_count
    FROM ug_curriculum
    WHERE department_id = dept_id
      AND year = grad_year;

    FOR current_course IN (SELECT course_enrollments.course_code, course_enrollments.grade, course_type
                           FROM course_enrollments
                                    JOIN course_mappings
                                         ON course_mappings.course_code = course_enrollments.course_code AND
                                            course_mappings.semester = course_enrollments.semester
                                    JOIN course_catalog ON course_catalog.course_code = course_enrollments.course_code
                           WHERE course_enrollments.student_id = $1
                             AND course_enrollments.grade != 'F')
        LOOP

        end loop;
    Return TRUE;
END;
$$;

alter function check_student_requirements(integer) owner to postgres;

