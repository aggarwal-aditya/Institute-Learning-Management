create function generate_transcript(p_student_id character varying, p_semester character varying)
    returns TABLE(course_code character varying, course_name character varying, grade character varying, credits integer, semester_gpa numeric, cumulative_gpa numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT course_enrollments.course_code,
               course_catalog.course_name,
               course_enrollments.grade,
               course_catalog.credit_str[5],
               (SELECT SUM(grade_mapping.value * course_catalog.credit_str[5]) / SUM(course_catalog.credit_str[5])
                FROM course_enrollments
                         JOIN course_catalog ON course_enrollments.course_code = course_catalog.course_code
                         JOIN grade_mapping ON course_enrollments.grade = grade_mapping.grade
                WHERE course_enrollments.student_id = p_student_id
                  AND course_enrollments.semester = p_semester),
               calculate_cgpa(p_student_id)
        FROM course_enrollments
                 JOIN course_catalog ON course_enrollments.course_code = course_catalog.course_code
        WHERE course_enrollments.student_id = p_student_id
          AND course_enrollments.semester = p_semester;
END;
$$;

alter function generate_transcript(varchar, varchar) owner to postgres;

